from monkeylearn import MonkeyLearn
ml = MonkeyLearn('57b16cb35f3eb6d9b4da93b87f91974c18e067ee')
model_id = 'cl_pi3C7JiL'
import pymysql
conn=pymysql.connect(host="localhost",user="root",password="root",db="n_gram")
cursor=conn.cursor()

class NGram:
    def analysis(self,id):
        cursor.execute("select * from stackoverflow where id='"+id+"'")
        datasetdetails=cursor.fetchall()
        sentence=''
        for d in datasetdetails:
            sentence=d[2]


        data = [sentence]
        result = ml.classifiers.classify(model_id, data)
        print(result)
        print("hi")
        data = result.body[0]
        data1 = data['classifications']
        result = data1[0]['tag_name']
        cursor.execute("update stackoverflow set result='"+result+"' where id='"+id+"'")
        conn.commit()

    def appReview(self,id):
        cursor.execute("select * from appreview where id='" + id + "'")
        datasetdetails = cursor.fetchall()
        sentence = ''
        for d in datasetdetails:
            sentence = d[2]

        data = [sentence]
        result = ml.classifiers.classify(model_id, data)
        print(result)
        print("hi")
        data = result.body[0]
        data1 = data['classifications']
        result = data1[0]['tag_name']
        cursor.execute("update appreview set result='" + result + "' where id='" + id + "'")
        conn.commit()

    def jireReview(self,id):
        cursor.execute("select * from jirereview where id='" + id + "'")
        datasetdetails = cursor.fetchall()
        sentence = ''
        for d in datasetdetails:
            sentence = d[5]

        data = [sentence]
        result = ml.classifiers.classify(model_id, data)
        print(result)
        print("hi")
        data = result.body[0]
        data1 = data['classifications']
        result = data1[0]['tag_name']
        cursor.execute("update jirereview set result='" + result + "' where id='" + id + "'")
        conn.commit()



