from lib2to3.pgen2 import driver

from selenium.common.exceptions import NoAlertPresentException
from textblob import TextBlob
import ctypes
from os import path
import NGRAMALGORITHUM
from flask import Flask, render_template, request,session,send_from_directory
import os
from datetime import date
import matplotlib.pyplot as plt
import plotly.graph_objects as go
import csv
plt.rcdefaults()
import numpy as np
import matplotlib.pyplot as plt

import MailSending
import paralleldots
from monkeylearn import MonkeyLearn
ml = MonkeyLearn('57b16cb35f3eb6d9b4da93b87f91974c18e067ee')
model_id = 'cl_pi3C7JiL'

app=Flask(__name__)
app.secret_key = 'jsbcdsjkvbdjkbvdjcbkjf'
paralleldots.set_api_key("HXZU01aajLJQhZYhqDtrPbB2yVQxfH61fehC7FouIu4")
import pymysql
conn=pymysql.connect(host="localhost",user="root",password="root",db="n_gram")
cursor=conn.cursor()
APP_ROOT = os.path.dirname(os.path.abspath(__file__))

@app.route('/')
def index():
    return render_template('index.html')


@app.route('/adminlogin')
def adminlogin():
    return render_template('adminlogin.html')


@app.route('/userlogin')
def userlogin():
    return render_template('userlogin.html')


@app.route('/adminlog1')
def adminlog1():
    username = request.args.get('username')
    password = request.args.get('password')
    if username == 'admin' and  password=='admin':
        return render_template('adminhome.html')
    else:
        return render_template('adminlogin.html')


@app.route('/adminhome')
def adminhome():

    return render_template('adminhome.html')


@app.route('/userregister')
def userregister():

    return render_template('userregister.html')

@app.route('/userregister1',methods=['POST'])
def userregister1():

    target = os.path.join(APP_ROOT, 'images/')
    for upload in request.files.getlist("file"):
        name = request.form.get('name')
        username = request.form.get('username')
        email = request.form.get('email')
        phone = request.form.get('phone')
        password = request.form.get('password')
        gender = request.form.get('gender')
        address = request.form.get('address')

        filename = upload.filename
        print(filename)
        destination = "/".join([target, filename])
        upload.save(destination)
        resultvalue = cursor.execute(
            "insert into userreg(name,username,email,phone,gender,address,password,image) values('" + name + "','" + username + "','" + email + "','" + phone + "','" + gender + "','" + address + "','" + password + "','" + filename + "')")
        conn.commit()
        print("hi")
        if resultvalue > 0:
            return render_template('userlogin.html')

        else:
            return render_template('userregister.html')



@app.route('/allusers')
def allusers():
    image_names = os.listdir('./images')
    resultvalue = cursor.execute(
        "select * from userreg where status='Unauthorized'")
    conn.commit()
    userDetails = cursor.fetchall()
    if resultvalue > 0:
        return render_template('viewUsers.html', userDetails=userDetails)
    else:
        return render_template('adminMsg.html', msg='Details not Available')

@app.route('/authorizeUsere')
def authorizeUsere():
    id=request.args.get('id')
    cursor.execute("select * from userreg where user_id='"+id+"'")
    fdel=cursor.fetchall()
    for f in fdel:
        email=f[3]

    a=cursor.execute("update userreg set status ='authorized' where user_id='"+id+"'")
    conn.commit()
    if a > 0:
        MailSending.EmailSending.send_email('','Activation Response','Your Registration Request Activated Form Admin',email)
        return  allusers()
    else:
        return allusers()


@app.route('/deleteuser')
def deleteuser():
    id = request.args.get('id')
    a=cursor.execute("delete from userreg where user_id='"+id+"'")
    conn.commit()
    if a > 0:
        return  allusers()
    else:
        return allusers()



@app.route('/upload/<filename>')
def send_image(filename):
        return send_from_directory("images", filename)

@app.route('/userlogin1')
def userlogin1():
    username = request.args.get('username')
    password = request.args.get('password')

    result = cursor.execute(" select * from userreg where username='" + username + "' and password='" + password + "' and status='authorized'")
    userDetails=cursor.fetchall()
    conn.commit()

    if result > 0:

        for user in userDetails:
            email=user[3]
            id = user[0]
            print(email)

            session['username'] = username
            session['email']=email
            session['id']=id

            return render_template('userHome.html')


    else:
        return render_template('userlogin.html')



@app.route('/userlogout')
def userlogout():
    print("hellow message")
    session.pop('username', None)
    session.pop('id',None)
    session.pop('email',None)
    return render_template("index.html")

@app.route('/myprofile')
def myprofile():
    username=session['username']
    cursor.execute("select * from userreg where username='"+username+"'")
    details=cursor.fetchall()
    return render_template('myprofile.html',userdetails=details)


@app.route('/search')
def search():
    return render_template('search.html')

@app.route('/search1')
def search1():
    username=request.args.get('username')
    cursor.execute("select * from userreg where username='"+username+"'")
    details=cursor.fetchall()
    return render_template('searchresult.html',userdetails=details)

@app.route('/sendRequest')
def sendRequest():
    reqto=request.args.get('reqto')
    reqtoid = request.args.get('reqtoid')
    reqfrom=session['username']
    print(reqfrom)
    if reqto == reqfrom:

        return render_template('userMessage.html', msg="You Can not send Friend Request by Your Self")

    else:

        c=cursor.execute("select * from friendreq where reqto='"+reqto+"' or reqfrom='"+reqfrom+"' and status='accept'")

        b=cursor.execute("select * from friendreq where reqto='"+reqto+"' or reqfrom='"+reqfrom+"'")
        if b > 0:
            return  render_template('userMessage.html',msg="you already send friend request waitng for response")
        elif c > 0:
            return  render_template('userMessage.html',msg="you already  friend")
        else:

            a=cursor.execute("insert into friendreq(reqto,reqtoid,reqfrom) values('"+reqto+"','"+reqtoid+"','"+reqfrom+"')")
            conn.commit()

            if a  > 0:
                return render_template('userMessage.html', msg="Friend Request Sent Sucessfully")
            else:
                return render_template('userMessage.html', msg="Friend Request sent fails")


@app.route('/viewFriendreqdel')
def viewFriendreqdel():
    reqto=session['username']
    a=cursor.execute("select * from friendreq where reqto='"+reqto+"' and status='pending'")
    details=cursor.fetchall()
    if a > 0:
        return render_template('viewFriendRequest.html',reqdetails=details)
    else:
        return render_template('userMessage.html', msg="Friend Request Details not available")


@app.route('/clickhere')
def clickhere():
    reqfrom=request.args.get('reqfrom')
    cursor.execute("select * from userreg where username='" + reqfrom + "'")
    details = cursor.fetchall()
    return render_template('userprofile.html', userdetails=details)


@app.route('/Acceptreq')
def Acceptreq():
    id = request.args.get('id')
    a=cursor.execute("update friendreq set status='accept' where id='"+id+"'")
    conn.commit()
    if a > 0:
        return viewFriendreqdel()
    else:
        return render_template('userMessage.html', msg="Friend Request Accepted Fails")


@app.route('/myfriends')
def myfriends():
    username=session['username']
    a=cursor.execute("select * from friendreq where reqfrom='"+username+"' or reqto='"+username+"' and status='accept'")
    details=cursor.fetchall()
    if a > 0 :
        return render_template('myfriends.html', userdetails=details)
    else:
        return render_template('userMessage.html', msg="Friend Details are not available")


@app.route('/makepost')
def makepost():
    return render_template('makepost.html')

@app.route('/upload1',methods=['post'])
def upload1():
    print("hii 1")
    target = os.path.join(APP_ROOT, 'images/')
    print("hii2")
    print(request.files.getlist("file"))
    for upload in request.files.getlist("file"):
        username=session['username']
        descr = request.form.get('descr')

        filename = upload.filename
        destination = "/".join([target, filename])
        upload.save(destination)
        data = [descr]
        result = ml.classifiers.classify(model_id, data)
        print(result)
        print("hi")
        data = result.body[0]
        data1 = data['classifications']
        posttype = data1[0]['tag_name']

        a=cursor.execute("insert into post(postby,descr,image,result) values('" + username + "','" + descr + "','" + upload.filename + "','"+posttype+"')")
        conn.commit()
        if a > 0:



            return render_template('userMessage.html',msg='Posting Sucess')
        else:
            return render_template('userMessage.html',msg='Posting Fails')


@app.route('/userhome')
def userhome():
    username=session['username']
    cursor.execute("select * from post where postby !='"+username+"'")
    details=cursor.fetchall()
    return render_template('userhome.html',postdetails=details)

@app.route('/mypost')
def mypost():
    username = session['username']
    cursor.execute("select * from post where postby ='" + username + "'")
    details = cursor.fetchall()
    return render_template('mypost.html', postdetails=details)

@app.route('/recommend')
def recommend():
    postid=request.args.get('id')
    username = session['username']
    a = cursor.execute(
        "select * from friendreq where reqfrom='" + username + "' or reqto='" + username + "' and status='accept'")
    details = cursor.fetchall()
    friends=[]
    for roww in details:
        if username != roww[1]:
            friends.append(roww[1])
        elif username != roww[2]:
            friends.append(roww[2])

    print(friends)
    if a > 0:
        return render_template('recommend.html', userdetails=friends,postid=postid,recommendby=username)
    else:
        return render_template('userMessage.html', msg="Friend Details are not available")



@app.route('/recommend1')
def recommend1():
    postid = request.args.get('postid')
    recommendto = request.args.get('recommendto')
    recommendfrom = session['username']
    a=cursor.execute("insert into recommend(postid,recommendby,recommendto,timee) values('"+postid+"','"+recommendfrom+"','"+recommendto+"',now())")
    conn.commit()
    if a > 0 :
        return mypost()
    else:
        return mypost()

@app.route('/viewrecommendpost')
def viewrecommendpost():
    username=session['username']
    a=cursor.execute("select * from recommend where recommendto='"+username+"'")
    details=cursor.fetchall()
    postdetails="";
    if a > 0:
        for roww in details:

            b=cursor.execute("select * from post where id='"+roww[1]+"'")
            postdetails=cursor.fetchall()
        return render_template('viewrecommendpost.html',details=postdetails)
    else:
        return render_template('userMessage.html',msg='details are not available')




@app.route('/viewfriendsdel')
def viewfriendsdel():
    a=cursor.execute("select * from friendreq")
    details=cursor.fetchall()
    if a > 0 :
        return render_template('viewfriends.html', userdetails=details)
    else:
        return render_template('adminMsg.html', msg="Friend Details are not available")



@app.route('/viewpostdel')
def viewpostdel():
    cursor.execute("select * from post")
    details=cursor.fetchall()
    return render_template('viewpost.html',postdetails=details)



@app.route('/viewrecommendpost1')
def viewrecommendpost1():
    a=cursor.execute("select * from recommend")
    details=cursor.fetchall()
    postdetails="";
    if a > 0:
        for roww in details:

            b=cursor.execute("select * from post where id='"+roww[1]+"'")
            postdetails=cursor.fetchall()
        return render_template('aviewrecommendpost.html',details=postdetails)
    else:
        return render_template('adminMsg.html',msg='details are not available')


@app.route('/viewpnpost')
def viewpnpost():

    return render_template('viewpnpost.html')


@app.route('/viewpnpost1')
def viewpnpost1():
    posttype=request.args.get('posttype')
    a=cursor.execute("select * from pnpost where posttype='"+posttype+"'")
    if a > 0:
        my_tuple = ()

        details=cursor.fetchall()
        for roww in details:
            b=cursor.execute("select * from post where id='"+roww[1]+"'")
            my_tuple=cursor.fetchall()+my_tuple;
            print(my_tuple)



            print("hi")
        print(my_tuple)
        return render_template('viewpnpost1.html', pdetails=my_tuple)


    else:
        return render_template('adminMsg.html',msg='details are not available')




@app.route('/uploadstackoverflow')
def uploadstackoverflow():
    return render_template('uploadstackoverflow.html')




@app.route('/uploadstackoverflow1',methods=['POST'])
def uploadstackoverflow1():
    my_path = os.path.abspath(os.path.dirname(__file__))
    print(my_path)
    print(APP_ROOT)
    basepath = path.dirname(__file__)
    print(basepath)
    target = os.path.join(APP_ROOT, 'csv')
    print("hi")
    filename="s.csv"
    print(target+"\\"+filename)
    for upload in request.files.getlist("file"):
        profilepic = upload.filename
        new_path = os.path.realpath(target)

        destination = "/".join([target, profilepic])
        upload.save(destination)

        with open(target+"\\"+profilepic) as csvfile:
            reader = csv.DictReader(csvfile, delimiter=',')
            for row in reader:
                # insert
                sql_statement = "INSERT INTO stackoverflow(QUESTION,ANSWER,DATEE,TIMEE) VALUES (%s,%s,%s,%s)"
                cursor.executemany(sql_statement, [
                    (row['QUESTION'], row['ANSWER'], row['DATE'], row['TIME'])])
                conn.escape_string(sql_statement)
                conn.commit()
                postid = cursor.lastrowid
                NGRAMALGORITHUM.NGram.analysis('', str(postid))





    ctypes.windll.user32.MessageBoxW(0,
                                     "CSV File Uploded Success",
                                     "Upload status",
                                     "color:black;")
    return render_template('adminhome.html')

@app.route('/uploadappreview')
def uploadappreview():
    return render_template('uploadappreview.html')




@app.route('/uploadappreview1',methods=['POST'])
def uploadappreview1():
    my_path = os.path.abspath(os.path.dirname(__file__))
    print(my_path)
    print(APP_ROOT)
    basepath = path.dirname(__file__)
    print(basepath)
    target = os.path.join(APP_ROOT, 'csv')
    print("hi")
    filename="s.csv"
    print(target+"\\"+filename)
    for upload in request.files.getlist("file"):
        profilepic = upload.filename
        new_path = os.path.realpath(target)

        destination = "/".join([target, profilepic])
        upload.save(destination)

        with open(target+"\\"+profilepic) as csvfile:
            reader = csv.DictReader(csvfile, delimiter=',')
            for row in reader:
                # insert
                sql_statement = "INSERT INTO appreview(appname,datee,review) VALUES (%s,%s,%s)"
                cursor.executemany(sql_statement, [
                    (row['APPS'], row['DATE'], row['REVIEWS'])])
                conn.escape_string(sql_statement)
                print(sql_statement)
                conn.commit()
                postid = cursor.lastrowid
                NGRAMALGORITHUM.NGram.appReview('', str(postid))






    ctypes.windll.user32.MessageBoxW(0,
                                     "CSV File Uploded Success",
                                     "Upload status",
                                     "color:black;")
    return render_template('adminhome.html')


@app.route('/uploadjirareview')
def uploadjirareview():
    return render_template('uploadjirareview.html')




@app.route('/uploadjirareview1',methods=['POST'])
def uploadjirareview1():
    my_path = os.path.abspath(os.path.dirname(__file__))

    basepath = path.dirname(__file__)
    target = os.path.join(APP_ROOT, 'csv')

    for upload in request.files.getlist("file"):
        profilepic = upload.filename
        new_path = os.path.realpath(target)

        destination = "/".join([target, profilepic])
        upload.save(destination)

        with open(target+"\\"+profilepic) as csvfile:
            reader = csv.DictReader(csvfile, delimiter=',')
            for row in reader:
                # insert
                sql_statement = "INSERT INTO jirereview(bugid,summary,os,Severity,Description) VALUES (%s,%s,%s,%s,%s)"
                cursor.executemany(sql_statement, [
                    (row['Bug.ID'], row['Summary'],row['OS'], row['Severity'],row['Description'])])
                conn.escape_string(sql_statement)
                print(sql_statement)
                conn.commit()
                postid = cursor.lastrowid
                NGRAMALGORITHUM.NGram.jireReview('', str(postid))






    ctypes.windll.user32.MessageBoxW(0,
                                     "CSV File Uploded Success",
                                     "Upload status",
                                     "color:black;")
    return render_template('adminhome.html')



@app.route('/viewstackoverflow')
def viewstackoverflow():
    a=cursor.execute("select * from stackoverflow")
    stackdel=cursor.fetchall()
    print(stackdel)
    positive=cursor.execute("select * from stackoverflow where result='Positive'")
    negative=cursor.execute("select * from stackoverflow where result='Negative'")
    neutral=cursor.execute("select * from stackoverflow where result='Neutral'")

    if a > 0:
        return render_template('viewstackanalysis.html',stack=stackdel)
    else:
        ctypes.windll.user32.MessageBoxW(0,
                                         "CSV File Uploded Details not Available",
                                         "Upload status",
                                         "color:black;")
        return render_template('adminhome.html')


@app.route('/viewappreview')
def viewappreview():
    a=cursor.execute("select * from appreview")
    stackdel=cursor.fetchall()
    print(stackdel)
    positive=cursor.execute("select * from appreview where result='Positive'")
    negative=cursor.execute("select * from appreview where result='Negative'")
    neutral=cursor.execute("select * from appreview where result='Neutral'")

    if a > 0:
        return render_template('viewappreviewanalysis.html',stack=stackdel)
    else:
        ctypes.windll.user32.MessageBoxW(0,
                                         "CSV File Uploded Details not Available",
                                         "Upload status",
                                         "color:black;")
        return render_template('adminhome.html')




@app.route('/viewjirareview')
def viewjirareview():
    a=cursor.execute("select * from jirereview")
    stackdel=cursor.fetchall()
    print(stackdel)
    positive=cursor.execute("select * from jirereview where result='Positive'")
    negative=cursor.execute("select * from jirereview where result='Negative'")
    neutral=cursor.execute("select * from jirereview where result='Neutral'")

    if a > 0:
        return render_template('viewjirareviewanalysis.html',stack=stackdel)
    else:
        ctypes.windll.user32.MessageBoxW(0,
                                         "CSV File Uploded Details not Available",
                                         "Upload status",
                                         "color:black;")
        return render_template('adminhome.html')




@app.route('/graph')
def graph():
    return render_template('graph.html')

@app.route('/pigraph')
def pigraph():
    return render_template('pigraph.html')

@app.route('/piegraph1')
def piegraph1():
    dataset=request.args.get('dataset')
    print(dataset)
    if dataset == 'stack':
        a = cursor.execute("select * from stackoverflow")
        if a > 0:
            positive = cursor.execute("select * from stackoverflow where result='Positive'")
            negative = cursor.execute("select * from stackoverflow where result='Negative'")
            neutral = cursor.execute("select * from stackoverflow where result='Neutral'")

            labels = 'Positive', 'Negative', 'Neutral'
            sizes = [positive, negative, neutral]
            explode = (0, 0.1, 0)  # only "explode" the 2nd slice (i.e. 'Hogs')

            fig1, ax1 = plt.subplots()
            ax1.pie(sizes, explode=explode, labels=labels, autopct='%1.1f%%',
                    shadow=True, startangle=90)
            ax1.axis('equal')  # Equal aspect ratio ensures that pie is drawn as a circle.

            plt.show()
            return render_template('graph.html')


        else:
            ctypes.windll.user32.MessageBoxW(0,
                                             "CSV File Uploded Details not Available",
                                             "Upload status",
                                             "color:black;")
            return render_template('adminhome.html')


    elif dataset == 'jira':
        a = cursor.execute("select * from jirereview")

        if a > 0:
            positive = cursor.execute("select * from jirereview where result='Positive'")
            negative = cursor.execute("select * from jirereview where result='Negative'")
            neutral = cursor.execute("select * from jirereview where result='Neutral'")

            labels = 'Positive', 'Negative', 'Neutral'
            sizes = [positive, negative, neutral]
            explode = (0, 0.1, 0)  # only "explode" the 2nd slice (i.e. 'Hogs')

            fig1, ax1 = plt.subplots()
            ax1.pie(sizes, explode=explode, labels=labels, autopct='%1.1f%%',
                    shadow=True, startangle=90)
            ax1.axis('equal')  # Equal aspect ratio ensures that pie is drawn as a circle.

            plt.show()
            return render_template('graph.html')


        else:
            ctypes.windll.user32.MessageBoxW(0,
                                             "CSV File Uploded Details not Available",
                                             "Upload status",
                                             "color:black;")
            return render_template('adminhome.html')
    elif dataset == 'app':
        a = cursor.execute("select * from appreview")

        if a > 0:
            positive = cursor.execute("select * from appreview where result='Positive'")
            negative = cursor.execute("select * from appreview where result='Negative'")
            neutral = cursor.execute("select * from appreview where result='Neutral'")

            labels = 'Positive', 'Negative', 'Neutral'
            sizes = [positive, negative, neutral]
            explode = (0, 0.1, 0)  # only "explode" the 2nd slice (i.e. 'Hogs')

            fig1, ax1 = plt.subplots()
            ax1.pie(sizes, explode=explode, labels=labels, autopct='%1.1f%%',
                    shadow=True, startangle=90)
            ax1.axis('equal')  # Equal aspect ratio ensures that pie is drawn as a circle.

            plt.show()
            return render_template('graph.html')


        else:
            ctypes.windll.user32.MessageBoxW(0,
                                             "CSV File Uploded Details not Available",
                                             "Upload status",
                                             "color:black;")
            return render_template('adminhome.html')


@app.route('/bargraph')
def bargraph():
    return render_template('bargraph.html')


@app.route('/bargraph1')
def bargraph1():
    dataset=request.args.get('dataset')
    print(dataset)
    if dataset == 'stack':
        a = cursor.execute("select * from stackoverflow")
        if a > 0:
            positive = cursor.execute("select * from stackoverflow where result='Positive'")
            negative = cursor.execute("select * from stackoverflow where result='Negative'")
            neutral = cursor.execute("select * from stackoverflow where result='Neutral'")

            objects = ('Positive', 'Negative', 'Neutral')
            y_pos = np.arange(len(objects))
            performance = [positive, negative, neutral]

            plt.bar(y_pos, performance, align='center', alpha=0.5)
            plt.xticks(y_pos, objects)
            plt.ylabel('count')
            plt.title('Stack Overflow n-gram Analysis')

            plt.show()
            return render_template('graph.html')


        else:
            ctypes.windll.user32.MessageBoxW(0,
                                             "CSV File Uploded Details not Available",
                                             "Upload status",
                                             "color:black;")
            return render_template('adminhome.html')


    elif dataset == 'jira':
        a = cursor.execute("select * from jirereview")

        if a > 0:
            positive = cursor.execute("select * from jirereview where result='Positive'")
            negative = cursor.execute("select * from jirereview where result='Negative'")
            neutral = cursor.execute("select * from jirereview where result='Neutral'")

            objects = ('Positive', 'Negative', 'Neutral')
            y_pos = np.arange(len(objects))
            performance = [positive, negative, neutral]

            plt.bar(y_pos, performance, align='center', alpha=0.5)
            plt.xticks(y_pos, objects)
            plt.ylabel('count')
            plt.title('JIRA Review n-gram Analysis')
            plt.show()
            return render_template('graph.html')


        else:
            ctypes.windll.user32.MessageBoxW(0,
                                             "CSV File Uploded Details not Available",
                                             "Upload status",
                                             "color:black;")
            return render_template('adminhome.html')
    elif dataset == 'app':
        a = cursor.execute("select * from appreview")

        if a > 0:
            positive = cursor.execute("select * from appreview where result='Positive'")
            negative = cursor.execute("select * from appreview where result='Negative'")
            neutral = cursor.execute("select * from appreview where result='Neutral'")

            objects = ('Positive', 'Negative', 'Neutral')
            y_pos = np.arange(len(objects))
            performance = [positive, negative, neutral]

            plt.bar(y_pos, performance, align='center', alpha=0.5)
            plt.xticks(y_pos, objects)
            plt.ylabel('count')
            plt.title('APP Review n-gram Analysis')
            plt.show()
            return render_template('graph.html')


        else:
            ctypes.windll.user32.MessageBoxW(0,
                                             "CSV File Uploded Details not Available",
                                             "Upload status",
                                             "color:black;")
            return render_template('adminhome.html')


@app.route('/usergraph')
def usergraph():
    return render_template('usergraph.html')

@app.route('/upigraph')
def upigraph():
    print("select * from  post where postby='"+session['username']+"' ")
    a=cursor.execute("select * from post where postby='"+session['username']+"'")

    if a > 0:
        Positive = cursor.execute("select * from post where postby='" + session['username'] + "' and result='Positive'")
        Negative = cursor.execute("select * from post  where postby='" + session['username'] + "' and result='Negative'")
        Neutral = cursor.execute("select * from post  where postby='" + session['username'] + "' and result='Neutral'")
        labels = 'Positive', 'Negative', 'Neutral'
        sizes = [Positive, Negative, Neutral]
        explode = (0, 0.1, 0)  # only "explode" the 2nd slice (i.e. 'Hogs')

        fig1, ax1 = plt.subplots()
        ax1.pie(sizes, explode=explode, labels=labels, autopct='%1.1f%%',
                shadow=True, startangle=90)
        ax1.axis('equal')  # Equal aspect ratio ensures that pie is drawn as a circle.

        plt.show()
        return render_template('usergraph.html')



    else:
        ctypes.windll.user32.MessageBoxW(0,
                                         "Post Details not Available",
                                         "Upload status",
                                         "color:black;")
        return render_template('adminhome.html')



@app.route('/ubargraph')
def ubargraph():
    a=cursor.execute("select * from post where postby='"+session['username']+"'")
    if a > 0:
        Positive = cursor.execute("select * from post where postby='" + session['username'] + "' and result='Positive'")
        Negative = cursor.execute("select * from post where postby='" + session['username'] + "' and result='Negative'")
        Neutral = cursor.execute("select * from post where postby='" + session['username'] + "' and result='Neutral'")
        objects = ('Positive', 'Negative', 'Neutral')
        y_pos = np.arange(len(objects))
        performance = [Positive, Negative, Neutral]

        plt.bar(y_pos, performance, align='center', alpha=0.5)
        plt.xticks(y_pos, objects)
        plt.ylabel('count')
        plt.title('APP Review n-gram Analysis')
        plt.show()
        return render_template('usergraph.html')



    else:
        ctypes.windll.user32.MessageBoxW(0,
                                         "Post Details not Available",
                                         "Upload status",
                                         "color:black;")
        return render_template('adminhome.html')



if __name__ == '__main__':
    app.run(debug=True)